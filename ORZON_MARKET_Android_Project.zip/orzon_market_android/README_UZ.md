# ORZON MARKET Android ilovasi

Bu Android Studio loyihasi foydalanuvchi bergan Netlify saytini WebView ichida ochadi.
Ilova nomi: **ORZON MARKET**. Launcher belgisi foydalanuvchi yuborgan logotipdan tayyorlandi.

## APK yaratish
1. Kompyuterga Android Studio o‘rnating.
2. Ushbu papkani Android Studio orqali oching.
3. Gradle sinxronizatsiyasi tugashini kuting.
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)** ni bosing.
5. APK `app/build/outputs/apk/debug/app-debug.apk` ichida hosil bo‘ladi.

## GitHub orqali avtomatik APK
Loyihani GitHub repositoryga yuklang. Actions bo‘limidagi **Build ORZON MARKET APK** workflow avtomatik ishga tushadi. Tugagach, `ORZON-MARKET-APK` artifactini yuklab oling.

Ilova ishlashi uchun internet kerak. Buyurtma, katalog, admin va server funksiyalari saytning o‘zida ishlaydi. Kamera/galereya fayl tanlash oynasi WebView orqali qo‘llab-quvvatlanadi.
